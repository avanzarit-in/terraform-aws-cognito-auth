"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const mustache_1 = require("mustache");
const _1 = require("../_");
class InvitationMessage extends _1.Message {
    constructor(data) {
        super("invite", data);
        this.data = data;
    }
    get subject() {
        return mustache_1.render("Register your {{name}} account", this.data);
    }
}
exports.InvitationMessage = InvitationMessage;
