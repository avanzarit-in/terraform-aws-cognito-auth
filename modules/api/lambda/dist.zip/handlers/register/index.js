"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const clients_1 = require("../../clients");
const utilities_1 = require("../../utilities");
const _1 = require("../_");
const schema = require("../../common/events/register/index.json");
exports.post = _1.handler(schema, async ({ body: { email, password } }) => {
    utilities_1.throwOnPasswordPolicyViolation(password);
    const auth = new clients_1.AuthenticationClient();
    await auth.register(email, password);
});
