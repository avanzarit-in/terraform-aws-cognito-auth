"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const clients_1 = require("../../../clients");
const verification_1 = require("../../../verification");
const _1 = require("../../_");
const schema = require("../../../common/events/register/verify/index.json");
exports.post = _1.handler(schema, async ({ pathParameters: { code } }) => {
    try {
        const verification = new verification_1.Verification();
        const mgmt = new clients_1.ManagementClient();
        const { subject } = await verification.claim("register", code);
        await mgmt.verifyUser(subject);
    }
    catch (err) {
        err.statusCode = 403;
        throw err;
    }
});
