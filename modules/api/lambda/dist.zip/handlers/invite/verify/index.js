"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const verification_1 = require("../../../verification");
const _1 = require("../../_");
const schema = require("../../../common/events/invite/verify/index.json");
exports.post = _1.handler(schema, async ({ pathParameters: { code } }) => {
    try {
        const verification = new verification_1.Verification();
        const { subject } = await verification.claim("invite", code);
        return {
            body: {
                email: subject
            }
        };
    }
    catch (err) {
        err.statusCode = 403;
        throw err;
    }
});
