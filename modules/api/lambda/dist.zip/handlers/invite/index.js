"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const clients_1 = require("../../clients");
const _1 = require("../_");
const schema = require("../../common/events/invite/index.json");
exports.post = _1.handler(schema, async ({ body: { email } }) => {
    const auth = new clients_1.AuthenticationClient();
    await auth.invite(email);
});
