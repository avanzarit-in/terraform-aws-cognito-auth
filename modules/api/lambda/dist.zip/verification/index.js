"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const aws_sdk_1 = require("aws-sdk");
const crypto_1 = require("crypto");
const util_1 = require("util");
class Verification {
    constructor(dynamodb = new aws_sdk_1.DynamoDB.DocumentClient({
        apiVersion: "2012-08-10"
    }), sns = new aws_sdk_1.SNS({ apiVersion: "2010-03-31" })) {
        this.dynamodb = dynamodb;
        this.sns = sns;
    }
    async issue(context, subject) {
        const code = {
            id: (await util_1.promisify(crypto_1.randomBytes)(16)).toString("hex"),
            context,
            subject,
            expires: Math.floor(Date.now() / 1000) + 60 * 60 * 24
        };
        await Promise.all([
            this.dynamodb.put({
                TableName: process.env.DYNAMODB_TABLE,
                Item: code
            }).promise(),
            this.sns.publish({
                TopicArn: process.env.SNS_TOPIC_ARN,
                Message: JSON.stringify(code)
            }).promise()
        ]);
        return code;
    }
    async claim(context, id) {
        const { Attributes } = await this.dynamodb.delete({
            TableName: process.env.DYNAMODB_TABLE,
            Key: { id },
            ReturnValues: "ALL_OLD"
        }).promise();
        const code = Attributes;
        if (!code || code.context !== context)
            throw new Error(`Invalid verification code`);
        return code;
    }
}
exports.Verification = Verification;
