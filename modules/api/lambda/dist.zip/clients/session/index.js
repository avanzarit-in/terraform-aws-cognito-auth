"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const _1 = require("../_");
class SessionClient extends _1.Client {
    constructor(token) {
        super();
        this.token = token;
    }
    async signOut() {
        await this.cognito.globalSignOut({
            AccessToken: this.token
        }).promise();
    }
}
exports.SessionClient = SessionClient;
